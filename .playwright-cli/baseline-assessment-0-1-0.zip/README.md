# 基準評估表

- Project: prj_demo-studio
- Form: baseline-assessment
- Schema: 0.1.0

直接開啟 preview.html 可進行離線審查與下載 coded submission。正式 Renderer 驗證請在 repository/template/crf 執行：

AIRWAYAI_CRF_SCHEMA_PATH=forms/baseline-assessment/0.1.0/crf-schema.json npm run build

此包僅供 Demo／研究設計審查，不代表臨床正確性、法規提交適用性或 QMS 驗證完成。
